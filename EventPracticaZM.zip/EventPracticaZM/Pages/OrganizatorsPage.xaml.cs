﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EventPracticaZM.Classes;

namespace EventPracticaZM.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrganizatorsPage.xaml
    /// </summary>
    public partial class OrganizatorsPage : Page
    {
        public OrganizatorsPage()
        {
            InitializeComponent();
            ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.ToList();
        }

        private void editclient_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new OrganizatorsAddEditPage((Organizers)ListClients.SelectedItem));
        }

        private void DeleteClient_Click(object sender, RoutedEventArgs e)
        {
            var personForRemoving = ListClients.SelectedItems.Cast<Organizers>().ToList();
            var resMessage = MessageBox.Show("Удалить запись?", "Подтверждение",
             MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (resMessage == MessageBoxResult.Yes)
            {
                try
                {
                    ConferenceEntities.GetContext().Organizers.RemoveRange(personForRemoving);
                    ConferenceEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Данный клиент арендует помещение", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Pages.OrganizatorsAddEditPage(null));
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (CmbFiltrSort.Text == "По ФИО")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.Where(x => x.FIO.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
            if (CmbFiltrSort.Text == "По почте")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.Where(x => x.Email.ToString().ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
            if (CmbFiltrSort.Text == "По дате рождения")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.Where(x => x.DateOfBirth.ToString().ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
            if (CmbFiltrSort.Text == "По номеру телефона")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.Where(x => x.Phone.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void CmbFiltrSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (RbDown.IsChecked == true)
            {
                if (CmbFiltrSort.Text == "По ФИО")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderByDescending(x => x.FIO).ToList();
                if (CmbFiltrSort.Text == "По почте")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderByDescending(x => x.Email).ToList();
                if (CmbFiltrSort.Text == "По дате рождения")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderByDescending(x => x.DateOfBirth).ToList();
                if (CmbFiltrSort.Text == "По номеру телефона")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderByDescending(x => x.Phone).ToList();
            }
            if (RbUp.IsChecked == true)
            {
                if (CmbFiltrSort.Text == "По ФИО")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderBy(x => x.FIO).ToList();
                if (CmbFiltrSort.Text == "По почте")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderBy(x => x.Email).ToList();
                if (CmbFiltrSort.Text == "По дате рождения")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderBy(x => x.DateOfBirth).ToList();
                if (CmbFiltrSort.Text == "По номеру телефона")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderBy(x => x.Phone).ToList();
            }
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            if (CmbFiltrSort.Text == "По ФИО")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderBy(x => x.FIO).ToList();
            if (CmbFiltrSort.Text == "По почте")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderBy(x => x.Email).ToList();
            if (CmbFiltrSort.Text == "По дате рождения")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderBy(x => x.DateOfBirth).ToList();
            if (CmbFiltrSort.Text == "По номеру телефона")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderBy(x => x.Phone).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            if (CmbFiltrSort.Text == "По ФИО")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderByDescending(x => x.FIO).ToList();
            if (CmbFiltrSort.Text == "По почте")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderByDescending(x => x.Email).ToList();
            if (CmbFiltrSort.Text == "По дате рождения")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderByDescending(x => x.DateOfBirth).ToList();
            if (CmbFiltrSort.Text == "По номеру телефона")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Organizers.OrderByDescending(x => x.Phone).ToList();
        }
    }
}
