﻿using EventPracticaZM.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EventPracticaZM.Pages
{
    /// <summary>
    /// Логика взаимодействия для MembersPage.xaml
    /// </summary>
    public partial class MembersPage : Page
    {
        public MembersPage()
        {
            InitializeComponent();
            ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.ToList();
        }

        private void editclient_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new MembersAddEditPage((Participants)ListClients.SelectedItem));
        }

        private void DeleteClient_Click(object sender, RoutedEventArgs e)
        {
            var personForRemoving = ListClients.SelectedItems.Cast<Participants>().ToList();
            var resMessage = MessageBox.Show("Удалить запись?", "Подтверждение",
             MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (resMessage == MessageBoxResult.Yes)
            {
                try
                {
                    ConferenceEntities.GetContext().Participants.RemoveRange(personForRemoving);
                    ConferenceEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Данный клиент арендует помещение", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Pages.MembersAddEditPage(null));
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (CmbFiltrSort.Text == "По ФИО")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.Where(x => x.FIO.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
            if (CmbFiltrSort.Text == "По почте")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.Where(x => x.Email.ToString().ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
            if (CmbFiltrSort.Text == "По дате рождения")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.Where(x => x.DateOfBirth.ToString().ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
            if (CmbFiltrSort.Text == "По номеру телефона")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.Where(x => x.Phone.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void CmbFiltrSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (RbDown.IsChecked == true)
            {
                if (CmbFiltrSort.Text == "По ФИО")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderByDescending(x => x.FIO).ToList();
                if (CmbFiltrSort.Text == "По почте")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderByDescending(x => x.Email).ToList();
                if (CmbFiltrSort.Text == "По дате рождения")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderByDescending(x => x.DateOfBirth).ToList();
                if (CmbFiltrSort.Text == "По номеру телефона")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderByDescending(x => x.Phone).ToList();
            }
            if (RbUp.IsChecked == true)
            {
                if (CmbFiltrSort.Text == "По ФИО")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderBy(x => x.FIO).ToList();
                if (CmbFiltrSort.Text == "По почте")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderBy(x => x.Email).ToList();
                if (CmbFiltrSort.Text == "По дате рождения")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderBy(x => x.DateOfBirth).ToList();
                if (CmbFiltrSort.Text == "По номеру телефона")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderBy(x => x.Phone).ToList();

            }
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            if (CmbFiltrSort.Text == "По ФИО")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderBy(x => x.FIO).ToList();
            if (CmbFiltrSort.Text == "По почте")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderBy(x => x.Email).ToList();
            if (CmbFiltrSort.Text == "По дате рождения")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderBy(x => x.DateOfBirth).ToList();
            if (CmbFiltrSort.Text == "По номеру телефона")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderBy(x => x.Phone).ToList();

        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            if (CmbFiltrSort.Text == "По ФИО")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderByDescending(x => x.FIO).ToList();
            if (CmbFiltrSort.Text == "По почте")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderByDescending(x => x.Email).ToList();
            if (CmbFiltrSort.Text == "По дате рождения") 
                ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderByDescending(x => x.DateOfBirth).ToList();
            if (CmbFiltrSort.Text == "По номеру телефона")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Participants.OrderByDescending(x => x.Phone).ToList();
        }
    }
}
