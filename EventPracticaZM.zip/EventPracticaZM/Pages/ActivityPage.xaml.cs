﻿using EventPracticaZM.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EventPracticaZM.Pages
{
    /// <summary>
    /// Логика взаимодействия для ActivityPage.xaml
    /// </summary>
    public partial class ActivityPage : Page
    {
        public ActivityPage()
        {
            InitializeComponent();
            ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.ToList();
        }
        private void editclient_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new ActivityEditAddPage((Activities)ListBuildings.SelectedItem));
        }

        private void DeleteClient_Click(object sender, RoutedEventArgs e)
        {
            var personForRemoving = ListBuildings.SelectedItems.Cast<Activities>().ToList();
            var resMessage = MessageBox.Show("Удалить запись?", "Подтверждение",
             MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (resMessage == MessageBoxResult.Yes)
            {
                try
                {
                    ConferenceEntities.GetContext().Activities.RemoveRange(personForRemoving);
                    ConferenceEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Данное помещение нельзя удалить! Перед удалением помещения удалите арендатора и собственника помещения!", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Pages.ActivityEditAddPage(null));
        }

        private void CmbFiltrSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (RbDown.IsChecked == true)
            {
                if (CmbFiltrSort.Text == "По мероприятию")
                    ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderByDescending(x => x.Event.NameEvent).ToList();
                if (CmbFiltrSort.Text == "По дате начала")
                    ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderByDescending(x => x.TimeStart).ToList();
                if (CmbFiltrSort.Text == "По организатору")
                    ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderByDescending(x => x.Organizers.FIO).ToList();
                if (CmbFiltrSort.Text == "По модератору")
                    ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderByDescending(x => x.Moderators.FIO).ToList();
                if (CmbFiltrSort.Text == "По жюри")
                    ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderByDescending(x => x.Jury.FIO).ToList();
            }
            if (RbUp.IsChecked == true)
            {
                if (CmbFiltrSort.Text == "По мероприятию")
                    ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderBy(x => x.Event.NameEvent).ToList();
                if (CmbFiltrSort.Text == "По дате начала")
                    ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderBy(x => x.TimeStart).ToList();
                if (CmbFiltrSort.Text == "По организатору")
                    ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderBy(x => x.Organizers.FIO).ToList();
                if (CmbFiltrSort.Text == "По модератору")
                    ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderBy(x => x.Moderators.FIO).ToList();
                if (CmbFiltrSort.Text == "По жюри")
                    ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderBy(x => x.Jury.FIO).ToList();
            }
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (CmbFiltrSort.Text == "По мероприятию")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.Where(x => x.Event.NameEvent.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
            if (CmbFiltrSort.Text == "По дате начала")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.Where(x => x.TimeStart.ToString().ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
            if (CmbFiltrSort.Text == "По организатору")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.Where(x => x.Organizers.FIO.ToString().ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
            if (CmbFiltrSort.Text == "По модератору")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.Where(x => x.Moderators.FIO.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
            if (CmbFiltrSort.Text == "По жюри")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.Where(x => x.Jury.FIO.ToString().ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            if (CmbFiltrSort.Text == "По мероприятию")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderBy(x => x.Event.NameEvent).ToList();
            if (CmbFiltrSort.Text == "По дате начала")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderBy(x => x.TimeStart).ToList();
            if (CmbFiltrSort.Text == "По организатору")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderBy(x => x.Organizers.FIO).ToList();
            if (CmbFiltrSort.Text == "По модератору")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderBy(x => x.Moderators.FIO).ToList();
            if (CmbFiltrSort.Text == "По жюри")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderBy(x => x.Jury.FIO).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            if (CmbFiltrSort.Text == "По мероприятию")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderByDescending(x => x.Event.NameEvent).ToList();
            if (CmbFiltrSort.Text == "По дате начала")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderByDescending(x => x.TimeStart).ToList();
            if (CmbFiltrSort.Text == "По организатору")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderByDescending(x => x.Organizers.FIO).ToList();
            if (CmbFiltrSort.Text == "По модератору")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderByDescending(x => x.Moderators.FIO).ToList();
            if (CmbFiltrSort.Text == "По жюри")
                ListBuildings.ItemsSource = ConferenceEntities.GetContext().Activities.OrderByDescending(x => x.Jury.FIO).ToList();
        }
    }
}
