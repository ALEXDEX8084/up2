﻿using EventPracticaZM.Classes;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EventPracticaZM.Pages
{
    /// <summary>
    /// Логика взаимодействия для ActivityEditAddPage.xaml
    /// </summary>
    public partial class ActivityEditAddPage : Page
    {
        string imgLoc = "пусто";
        private Activities _currentperson = new Activities(); //экземпляр добавляемого пользователя
        public ActivityEditAddPage(Activities selectedUser)
        {
            InitializeComponent();
            if (selectedUser != null)
                _currentperson = selectedUser;
            DataContext = _currentperson;
            CmbFiltrOwner.ItemsSource = ConferenceEntities.GetContext().Activities.ToList();
            CmbFiltrOwner.SelectedValuePath = "IDOwner";
            CmbFiltrOwner.DisplayMemberPath = "SurName";
        }
        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentperson.TimeStart.ToString())) error.AppendLine("Укажите Адрес");
            if (string.IsNullOrWhiteSpace(PriceTxt.Text)) error.AppendLine("Укажите Цену");
            if (string.IsNullOrWhiteSpace(Areatxt.Text)) error.AppendLine("Укажите Площадь(м3)");
            if (string.IsNullOrWhiteSpace(CmbFiltrOwner.Text)) error.AppendLine("Укажите Собственника");
            if (string.IsNullOrWhiteSpace(renttxt.Text)) error.AppendLine("Укажите Цену аренды");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentperson.IDActivites == 0)
            {
                ConferenceEntities.GetContext().Activities.Add(_currentperson);
                try
                {
                    ConferenceEntities.GetContext().SaveChanges();// Сохранить изменения
                    MessageBox.Show("Данные сохраненны");
                    this.NavigationService.Navigate(new ActivityPage());
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }



        private void CmbFiltrOwner_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}